import java.util.Scanner ;
public class Chapter5_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int cm,feet ;
    double inch;
    Scanner input = new Scanner(System.in);
    System.out.print("Ű�� �Է��Ͻÿ� : ");
    cm = input.nextInt();
    inch = cm / 2.54 ;
    feet = (int)(inch/12);
    inch = inch - feet*12;
    System.out.print(cm +"cm�� ");
    System.out.print(feet +"��Ʈ "+inch +"��ġ�Դϴ�.");
    
    
	}

}
