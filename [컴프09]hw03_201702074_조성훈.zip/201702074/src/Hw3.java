
public class Hw3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
    for (int a = 0; a < 5 ; a++ ) {
	   for (int b = a ; b < 5 ; b++) {
	   System.out.print(" ");}
	   for (int b = 0; b < a ; b++) {
       System.out.print("*");}
	   for (int b = 0; b < a-1; b++) {
       System.out.print("*");} 	 
       System.out.println();   
       }
    for (int a = 0; a <5 ; a++) {
	    for (int b = 0; b<a ; b++) {
	    System.out.print(" ");}
	    for (int b = a ; b<5; b++) {
	    System.out.print("*");}
	    for (int b = a+1; b < 5; b++) {
	    System.out.print("*");}
	    
	    System.out.println();  
    }   
  }
}
	

