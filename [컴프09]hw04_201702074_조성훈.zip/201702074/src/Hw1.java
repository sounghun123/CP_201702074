import java.util.Random;

public class Hw1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Random rand = new Random(System.currentTimeMillis());
	System.out.println("<�ζ� ���� ���α׷�>");
    int i = 0;
    int j = 0;
    int arr[] = new int[6];
    for(i = 0; i<6; i++) {
    arr[i] = rand.nextInt(45)+1;
      for(j = 0; j<i ; j++) {
       if(arr[i]==arr[j]){
    	 i--;}
           }
    }
       	for (int k = 0; k<6; k++) {
       	   System.out.print(arr[k]);
       	   System.out.print(" ");
       	}
        
	}
}