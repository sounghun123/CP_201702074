class Box {
	private int width = 0 ;
	private int length = 0;
	private int height = 0;
	public int getWidth() {  return width; 	}
	public void setWidth(int w)  { width = w ; }
	public int getLength()  { return length;  }
    public void setLength(int l)  { length = l ; }
    public int getHeight()  { return height; }
    public void setHeight(int h) { height = h ;  }
    
    public int getVolume()
    { int volume ;
      volume = width*length*height ;
      return volume ;
    }
    public void print()   
    {}
    
} 
public class BoxTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Box myBox = new Box();
    
    myBox.setWidth(10);
    myBox.setLength(20);
    myBox.setHeight(50);
       
    System.out.println("�ڽ��� ���� ���̴� " + myBox.getWidth());
    System.out.println("�ڽ��� ���� ���̴� " + myBox.getLength());
    System.out.println("�ڽ��� ���̴� " + myBox.getHeight());
    System.out.println("�ڽ��� ���Ǵ� " + myBox.getVolume());	
    
	
	}
 }
