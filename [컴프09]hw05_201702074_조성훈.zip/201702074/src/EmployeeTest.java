class Employee {
	private String name ;
	private String phone ;
	private int income ;
	public String getName() { return name ;}
	public void setName(String n) { name = n ; }
	public String getPhone() { return phone ; }
	public void setPhone(String p) { phone = p ; }
	public int getIncome() { return income ; }
	public void setIncome(int i) { income = i;} 
	
	
}
public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Employee myEmployee = new Employee();
    
    myEmployee.setName("������");
    myEmployee.setPhone("010-1234-5678");
    myEmployee.setIncome(1000000000);
    
    System.out.println("������ �̸��� " + myEmployee.getName());
    System.out.println("������ ��ȭ��ȣ�� "+ myEmployee.getPhone());
    System.out.println("������ ������ " + myEmployee.getIncome());
    
	}

}
