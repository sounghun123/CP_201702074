import java.util.Scanner ;

public class Hw1 {
	//�޼ҵ� ¥��//
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner Input = new Scanner(System.in);
   String str ;
   System.out.print("���ڿ��� �Է��Ͻÿ� : ");
   str = Input.nextLine();
   int i,j ; 
   j = str.length();
   for(i = 0 ; i < j ; i ++)
   {
        System.out.print(str.charAt(j -i- 1));
	   }
      }
	}