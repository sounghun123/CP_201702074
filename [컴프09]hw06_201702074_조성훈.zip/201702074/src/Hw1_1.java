import java.util.Scanner;
//stringbuffer �̿�//
public class Hw1_1 {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String str;
		System.out.print("���ڿ��� �Է��Ͻÿ� : ");
		str = sc.nextLine();
		
		StringBuffer sb = new StringBuffer(str);
		sb.reverse();
		System.out.println(sb);
		
	}
}