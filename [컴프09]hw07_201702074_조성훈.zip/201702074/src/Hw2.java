class Plane {
	private String production ;
	private String model ;
	private int Maxpassenger ;
	public static int planes = 0 ;
	
	public String getproduction() {return production ;}
	public void setproduction(String p){ production = p ; }
	public String getmodel() { return model ; }
	public void setmodel(String m) { model = m ; }
	public int getMaxpassenger() {return Maxpassenger ; }
	public void setMaxpassenger(int Mp) { Maxpassenger = Mp ; }
	
	public Plane(String p , String m , int Mp) {
		production = p ;
		model = m ;
		Maxpassenger = Mp;
		planes ++;
	    
	}
	public Plane() { planes++; }
	public Plane(String p, String m) {
		production = p ;
		model = m;
		planes++;
		
	}
	public Plane(String p) {
		production = p ;
		planes++;
	}
	public static int getplanes() {
	   return planes ;	
	}

	
}
public class Hw2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Plane x1, x2, x3 , x4;
    x1 = new Plane("�����װ�", "����" , 500);
    x2 = new Plane(); 
    x3 = new Plane("�ƽþƳ�" , "�ƽþ�");
    x4 = new Plane("�����װ�");
    
    int n = Plane.getplanes();
    System.out.println("������ ����� �� : " + n);
	} 

}
