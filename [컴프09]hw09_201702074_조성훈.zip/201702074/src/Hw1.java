class Person {
	String name ;
	String address;
	String phone;
	
	public String getName() { return name ; }
	public void setName(String n) { name = n ; }
	public String getAddress() { return address;}
	public void setAddress(String a) { address = a ; }
	public String getPhone() { return phone;}
	public void setPhone(String p) { phone = p; }
	
	public Person() {
		name = "������";
		address = "����";
		phone = "010-1234-5678";
	}
}
class Customer extends Person {
	int number ;
	int mileage;
	
	public int getNumber() {return number ;}
	public void setNumber(int n) { number = n ;}
	public int getMileage() {return mileage;}
	public void setMileage(int m) {mileage = m;}
	
	public Customer() {
		number = 25;
		mileage = 500;
	}
	public void print() {
		System.out.println("�̸� : " + super.name);
		System.out.println("�ּ� : " + super.address);
		System.out.println("��ȭ ��ȣ : " + super.phone);
		System.out.println("���� ��ȣ : " + this.number);
		System.out.println("���ϸ��� : " + this.mileage);
	}
	}
	
public class Hw1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Customer cc = new Customer();
    cc.print();
	}

}
