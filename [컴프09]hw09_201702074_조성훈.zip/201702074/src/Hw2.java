class Student {
	String name ;
	String studentID ;
	String department ;
	String grade ;
	String credit;
	
	public String getName() { return name ; }
	public void setName(String n) { name = n ;}
	public String getStudentID() { return studentID ; }
	public void setStudentID(String s) { studentID = s ; }
	public String getDepartment() { return department;}
	public void setDepartment(String d) { department = d ;}
	public String getGrade() {return grade;}
	public void setGrade(String g) { grade = g ; }
	public String getCredit() { return credit ; }
	public void setCredit(String c) { credit = c ;}

	}
class UnderGraduate extends Student {
	String group ;
	
	public String getGroup() { return group;}
	public void setGroup(String g) { group = g;}
	
	public UnderGraduate() {
		name = "������" ;
		studentID = "201702074";
		department = "��ǻ�Ͱ��а�";
		grade = "1�г�";
		credit = "18����";
		group = "ARGOS" ;
	}
	public void print() {
		System.out.println("�̸� : " + super.name);
		System.out.println("�й� : " + super.studentID);
		System.out.println("�Ҽ� �а� : " + super.department);
		System.out.println("�г� : " + super.grade);
		System.out.println("�̼� ���� : " + super.credit);
		System.out.println("���Ƹ� : " + this.group );
	}
}
class Graduate extends Student {
	String assistant;
	String scholarship;
	
	public String getAssistant() {return assistant;}
	public void setAssistant(String a) { assistant = a ;}
	public String getScholarship() {return scholarship;}
	public void setScholarship(String s) { scholarship = s ;}
	
	public Graduate() {
		name = "ȫ�浿" ;
		studentID = "201102033";
		department = "��ǻ�Ͱ��а�";
		grade = "2�г�";
		credit = "10����";
		assistant = "���� ����";
		scholarship = "0.4";
	}
	public void print() {
		System.out.println("�̸� : " + super.name);
		System.out.println("�й� : " + super.studentID);
		System.out.println("�Ҽ� �а� : " + super.department);
		System.out.println("�г� : " + super.grade);
		System.out.println("�̼� ���� : " + super.credit);
		System.out.println("�ұ� ���� : " + this.assistant );
		System.out.println("���б� ���� : " + this.scholarship);
	}
}
public class Hw2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    UnderGraduate ug = new UnderGraduate();
    Graduate g = new Graduate();
    ug.print();
    System.out.println();
    g.print();
    
	}

}
