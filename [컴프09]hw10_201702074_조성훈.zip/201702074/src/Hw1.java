
class Shape {
	protected int width, height , area ;
	public Shape(int width, int height) {
		this.width = width;
		this.height = height;
	}
	public int area() {
		
		return area;
	}
	
};
class Triangle extends Shape {

	public Triangle(int width, int height) {
		super(width, height);
	}

	public int area() {
	area = (int)(0.5*width * height);
	 System.out.println("�ﰢ���� ���̴�  " + area);
	return area;
	}
};
class Rectangle extends Shape {
	public Rectangle(int width, int height) {
		super(width, height);
	}
	public int area() {
      area = width * height;
      System.out.println("�簢���� ���̴� " + area);
      return area ;
	}
};
class Circle extends Shape {
	public Circle(int width, int height) {
		super(width, height);
	}
	final double pi = 3.141592;
	public int area() {
	  height = width ;
	  
	  area = (int) (height * height  *  pi) ;
	  System.out.println("���� ���̴�  " + area );
	  return area;
	
}
};
public class Hw1 {
    private static Shape arrayOfShapes[];
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   init();
   DrawALL();
	}
	public static void init() {
		arrayOfShapes = new Shape[3];
		arrayOfShapes[0] = new Triangle(80,40);
		arrayOfShapes[1] = new Rectangle(25,46);
		arrayOfShapes[2] = new Circle(52,52);
	}
	public static void DrawALL() {
		for(int i = 0; i<arrayOfShapes.length; i++) {
			arrayOfShapes[i].area();
		}
			
	}

};
